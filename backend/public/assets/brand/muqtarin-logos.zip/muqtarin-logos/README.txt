MUQTARIN Store (مقترن ستور) - Brand Assets Package
==================================================
Tagline: مقترن ستور • نربط الفكرة بالتنفيذ

Contents:
- svg/logo.svg        : Primary horizontal lockup (light background)
- svg/logo-dark.svg   : Primary horizontal lockup (dark background)
- svg/icon.svg        : Standalone interlocking ribbon symbol
- png/logo.png        : High-res transparent PNG (1680x360, light)
- png/logo-dark.png   : High-res transparent PNG (1680x360, dark)
- png/icon-512.png    : Transparent square icon (512x512)
- png/icon-1024.png   : Transparent square icon (1024x1024)
- 3d/logo-3d.jpg      : 3D brand hero visual (1376x768)
- 3d/icon-3d.jpg      : 3D enamel/metallic icon (1024x1024)

Brand Colors:
- Primary Pine   : #0F4C3A
- Emerald Accent : #22C55E
- Warm Gold      : #F6C667
- Charcoal Ink   : #1F2937
- Slate Canvas   : #F8FAFC

Typography:
- Arabic  : Tajawal
- English : Inter / Space Grotesk
